set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ENV_FILE="$HERE/.env"

if [ -f "$ENV_FILE" ]; then
  set -a
  . "$ENV_FILE"
  set +a
fi

: "${PORT:=8787}"

echo "=== PROBE /pubkey ==="
curl -fsS -D - "http://127.0.0.1:${PORT}/pubkey" -o /tmp/sg_pubkey.json
echo "PUBKEY_BYTES=$(wc -c </tmp/sg_pubkey.json | tr -d ' ')"
head -c 200 /tmp/sg_pubkey.json; echo

echo
echo "=== PROBE /admit (intentional leak) ==="
INTENT='{"intent":{"action_type":"GIT_COMMIT_DIFF","payload":{"repo":"sg-week1-health","ref":"refs/heads/main","commit":"0000000000000000000000000000000000000000","diff_facts":[{"path":"README.md","line":1,"added":"OPENAI_SECRET_KEY=abc"}]}}}'
curl -fsS -D - -X POST "http://127.0.0.1:${PORT}/admit" -H "Content-Type: application/json" --data-binary "$INTENT" -o /tmp/sg_admit.json
echo "ADMIT_BYTES=$(wc -c </tmp/sg_admit.json | tr -d ' ')"
head -c 300 /tmp/sg_admit.json; echo

echo
echo "HEALTH_OK"
