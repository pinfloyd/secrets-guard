set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ENV_FILE="$HERE/.env"

if [ -f "$ENV_FILE" ]; then
  set -a
  . "$ENV_FILE"
  set +a
fi

: "${IMAGE_DIGEST:?missing IMAGE_DIGEST}"
: "${CUSTODY_ROOT:?missing CUSTODY_ROOT}"
: "${HOST:=0.0.0.0}"
: "${PORT:=8787}"
: "${STATE_PATH:=/data/state.json}"
: "${LOG_PATH:=/data/admit.log}"
: "${KEY_PATH:=/keys/authority.seedhex}"

KEYS_DIR="${CUSTODY_ROOT}/keys"
DATA_DIR="${CUSTODY_ROOT}/data"

echo "=== PREP_CUSTODY ==="
umask 077
mkdir -p "$KEYS_DIR" "$DATA_DIR"
chmod 700 "$CUSTODY_ROOT" "$KEYS_DIR" "$DATA_DIR" || true

# Ensure key exists (seedhex). If missing, create one deterministically from /dev/urandom (non-repeatable by design).
# This is not a crypto-contract change; it is custody initialization.
if [ ! -f "$KEYS_DIR/authority.seedhex" ]; then
  echo "=== INIT_KEY (authority.seedhex missing) ==="
  ( umask 077; head -c 32 /dev/urandom | xxd -p -c 256 > "$KEYS_DIR/authority.seedhex" )
  chmod 600 "$KEYS_DIR/authority.seedhex" || true
fi

echo "=== COMPOSE_UP ==="
HOST="$HOST" PORT="$PORT" STATE_PATH="$STATE_PATH" LOG_PATH="$LOG_PATH" KEY_PATH="$KEY_PATH" IMAGE_DIGEST="$IMAGE_DIGEST" CUSTODY_ROOT="$CUSTODY_ROOT" \
  docker compose -f "$HERE/docker-compose.yml" up -d

echo "=== WAIT_READY (/pubkey) ==="
for i in $(seq 1 30); do
  if curl -fsS "http://127.0.0.1:${PORT}/pubkey" >/dev/null 2>&1; then
    echo "READY=true"
    exit 0
  fi
  sleep 1
done

echo "READY=false"
docker ps -a || true
docker logs --tail 80 admit-authority || true
exit 12
